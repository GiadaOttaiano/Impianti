import pandas as pd

# Funzione per calcolare il Fairness Index
def getFairnessIndex(throughputList: list):
    numerator = sum(throughputList) ** 2
    denominator = len(throughputList) * sum([x ** 2 for x in throughputList])
    return numerator / denominator

# Percorso base dove sono salvati i file CSV
BASE_PATH = "C:\Users\Andrea\Desktop\Magistrale\Impianti Di Elaborazione\Fairness"

# Nominal Throughput per ogni test
ctt = [1000, 10000, 20000]
dataFrameReports = []

# Lettura dei dati dai CSV
dataFrameReports.append(pd.read_csv(BASE_PATH + "1.csv"))
dataFrameReports.append(pd.read_csv(BASE_PATH + "2.csv"))
dataFrameReports.append(pd.read_csv(BASE_PATH + "3.csv"))

# Lista per tenere traccia dei throughput calcolati
throughputs = []

# Calcolo del throughput per ciascun file di dati
for index, dataframe in enumerate(dataFrameReports):
    maxTimestamp = dataframe["timeStamp"].max()   # Massimo timestamp
    minTimestamp = dataframe["timeStamp"].min()   # Minimo timestamp
    duration = (maxTimestamp - minTimestamp) / 1000  # Durata in secondi

    totalOfRequests = dataframe["timeStamp"].count()  # Totale delle richieste

    # Throughput base (richieste per minuto)
    throughput = totalOfRequests / duration * 60

    # Normalizzazione rispetto al nominal throughput
    throughput_normalized = throughput / ctt[index]

    throughputs.append(throughput_normalized)

# Calcolo del Fair Throughput
fair_throughput = sum(throughputs) / len(throughputs)

# Calcolo del Normalized Throughput
normalized_throughputs = [x / fair_throughput for x in throughputs]

# Calcolo del Fair Throughput per ogni test
fair_throughputs = [fair_throughput * ctt[index] for index in range(len(ctt))]

# Visualizzazione dei risultati
print("\n--- Risultati dei Throughput ---\n")

for index in range(len(ctt)):
    print(f"Test {index + 1}:")
    print(f"  Nominal Throughput: {ctt[index]} richieste")
    print(f"  Throughput normalizzato: {throughputs[index]:.4f}")
    print(f"  Normalized Throughput: {normalized_throughputs[index]:.4f}")
    print(f"  Fair Throughput: {fair_throughputs[index]:.4f}\n")

print(f"Fair Throughput (medio): {fair_throughput:.4f}\n")
print(f"Fairness Index: {getFairnessIndex(throughputs):.4f}\n")