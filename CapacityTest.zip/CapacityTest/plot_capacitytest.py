import pandas as pd
import matplotlib.pyplot as plt
import os  # To handle file paths

root = 'C:/Users/Andrea/apache-jmeter-5.6.3/bin/'
ctt = ['100', '500', '1000', '3000', '5000', '7000']
sufx = ['1']

throps = []
elapsed = [] 
power_values = []

for c in ctt:
    throughputs = []
    times = []
    elaps_mean = []

    for s in sufx:
        file_path = os.path.join(root, f"{c}_{s}.csv")  # Ensure correct path formatting
        try:
            df = pd.read_csv(file_path)
            # Filtering and calculations
            df_success = df[df['success'] == True]
            start_time = df['timeStamp'].min()
            end_time = df['timeStamp'].max()
            total_time_sec = (end_time - start_time) / 1000
            total_requests = len(df_success)

            if total_time_sec > 0:
                throughput = total_requests / total_time_sec
                throughputs.append(throughput)
                elaps_mean.append(df_success['elapsed'].mean())
        except Exception as e:
            print(f"Could not read file {file_path}: {e}")
            continue

    if throughputs:
        avg_throughput = sum(throughputs) / len(throughputs)
        avg_elapsed = sum(elaps_mean) / len(elaps_mean) if elaps_mean else 0
        throps.append(avg_throughput)
        elapsed.append(avg_elapsed)
        power_values.append(avg_throughput / avg_elapsed if avg_elapsed > 0 else 0)

if throps and elapsed and power_values:
    # Plot Throughput
    plt.figure()
    plt.plot(ctt, throps, marker='o', linestyle='-', color='c', label='Throughput')
    plt.fill_between(ctt, throps, color='c', alpha=0.2)
    plt.title('Throughput')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.show()

    # Plot Response Time
    plt.figure()
    plt.plot(ctt, elapsed, marker='o', linestyle='-', color='g', label='Delay')
    plt.fill_between(ctt, elapsed, color='g', alpha=0.2)
    plt.title('Response Time')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.show()

    # Plot Power
    plt.figure()
    plt.plot(ctt, power_values, marker='o', linestyle='-', color='r', label='Power')
    plt.fill_between(ctt, power_values, color='r', alpha=0.2)
    plt.title('Power')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.show()
else:
    print("No data available to plot.")
