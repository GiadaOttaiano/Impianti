import pandas as pd
import matplotlib.pyplot as plt

# Lista dei valori del CTT
ctt_values = [100, 500, 1000, 3000, 5000, 7000]  # Cambiamo i valori in numerici

# Nomi delle colonne che corrispondono all'output di vmstat
columns = [
    'r', 'b', 'swpd', 'free', 'buff', 'cache', 'si', 'so', 'bi', 'bo',
    'in', 'cs', 'us', 'sy', 'id', 'wa', 'st'
]

# Funzione per leggere i dati dal file di output
def load_data(ctt):
    filename = f'output_{ctt}.txt'
    # Legge il file con separatori di spazi, salta le prime 2 righe di intestazione non necessarie
    df = pd.read_csv(filename, sep='\s+', skiprows=2, header=None, names=columns)
    df['CTT'] = ctt  # Aggiungiamo il CTT come colonna
    return df

# Lista per salvare i dati di tutti i file
data_frames = []

# Carichiamo i dati per tutti i CTT
for ctt in ctt_values:
    df = load_data(ctt)
    data_frames.append(df)

# Combiniamo i dati di tutti i CTT in un unico DataFrame
full_data = pd.concat(data_frames)

# Convertiamo il campo 'CTT' in tipo numerico (se non lo è già)
full_data['CTT'] = pd.to_numeric(full_data['CTT'])

# Ordiniamo i dati in base ai valori di CTT
full_data = full_data.sort_values(by='CTT')

# Creiamo una figura per i grafici
plt.figure(figsize=(15, 10))

# 1. Grafico per i processi in attesa (b)
plt.subplot(3, 2, 1)
b_values = full_data.groupby('CTT')['b'].mean()  # Media dei valori di 'b' per ogni CTT
plt.plot(b_values.index, b_values.values, marker='o', label='b (Waiting Processes)')
plt.title('Average Waiting Processes (b) vs CTT')
plt.xlabel('CTT')
plt.ylabel('Waiting Processes (b)')
plt.grid(True)

# 2. Grafico per la memoria (free, buff, cache)
plt.subplot(3, 2, 2)
memory_values = full_data.groupby('CTT')[['free', 'buff', 'cache']].mean()  # Media dei valori di memoria per ogni CTT
plt.plot(memory_values.index, memory_values['free'], label='Free Memory')
plt.plot(memory_values.index, memory_values['buff'], label='Buffer Memory')
plt.plot(memory_values.index, memory_values['cache'], label='Cache Memory')
plt.title('Average Memory Usage vs CTT')
plt.xlabel('CTT')
plt.ylabel('Memory (KB)')
plt.legend()
plt.grid(True)

# 3. Grafico per swapped-in e swapped-out (si, so)
plt.subplot(3, 2, 3)
swap_values = full_data.groupby('CTT')[['si', 'so']].mean()  # Media dei valori di swap per ogni CTT
plt.plot(swap_values.index, swap_values['si'], label='Swapped In')
plt.plot(swap_values.index, swap_values['so'], label='Swapped Out')
plt.title('Average Swapped In/Out vs CTT')
plt.xlabel('CTT')
plt.ylabel('KB')
plt.legend()
plt.grid(True)

# 4. Grafico per blocchi letti e scritti (bi, bo)
plt.subplot(3, 2, 4)
io_values = full_data.groupby('CTT')[['bi', 'bo']].mean()  # Media dei blocchi letti e scritti per ogni CTT
plt.plot(io_values.index, io_values['bi'], label='Blocks Read')
plt.plot(io_values.index, io_values['bo'], label='Blocks Written')
plt.title('Average IO Blocks (Read/Write) vs CTT')
plt.xlabel('CTT')
plt.ylabel('Blocks')
plt.legend()
plt.grid(True)

# 5. Grafico per interruzioni e context switches (in, cs)
plt.subplot(3, 2, 5)
interrupt_values = full_data.groupby('CTT')[['in', 'cs']].mean()  # Media delle interruzioni e context switches per ogni CTT
plt.plot(interrupt_values.index, interrupt_values['in'], label='Interrupts')
plt.plot(interrupt_values.index, interrupt_values['cs'], label='Context Switches')
plt.title('Average Interrupts and Context Switches vs CTT')
plt.xlabel('CTT')
plt.ylabel('Count')
plt.legend()
plt.grid(True)

# 6. Grafico per User Time, Kernel Time, Idle Time e I/O Waiting Time
plt.subplot(3, 2, 6)
cpu_values = full_data.groupby('CTT')[['us', 'sy', 'id', 'wa']].mean()  # Media dei tempi CPU per ogni CTT
plt.plot(cpu_values.index, cpu_values['us'], label='User Time')
plt.plot(cpu_values.index, cpu_values['sy'], label='Kernel Time')
plt.plot(cpu_values.index, cpu_values['id'], label='Idle Time')
plt.plot(cpu_values.index, cpu_values['wa'], label='I/O Waiting Time')
plt.title('Average CPU Time Breakdown vs CTT')
plt.xlabel('CTT')
plt.ylabel('Time (%)')
plt.legend()
plt.grid(True)

# Mostriamo tutti i grafici
plt.tight_layout()
plt.show()
