from glob import glob
import pandas as pd
import numpy as np

# Percorso della cartella con i file CSV
root = r"C:/Users/Andrea/Desktop/Magistrale/Impianti Di Elaborazione/Fairness/*"

# Lista dei throughput nominali (in secondi)
nominal_throughputs = [8000, 6000, 4000, 4000, 6000, 8000, 8000, 6000, 4000]
nominal_throughputs = [x / 60 for x in nominal_throughputs]  # Converti in throughput per secondo

# Liste per throughput misurati e fairness index
measured_throughputs = []

# Elaborazione dei file CSV
for val in sorted(glob(root)):
    print(f"Elaborazione del file: {val}")
    data = pd.read_csv(val)
    
    # Calcola il throughput misurato
    duration = (data["timeStamp"].max() - data["timeStamp"].min()) / 1000  # Durata in secondi
    throughput = data[data["responseMessage"] == "OK"].shape[0] / duration  # Richieste al secondo
    
    measured_throughputs.append(throughput)

# Normalizzazione dei throughput
normalized_throughputs = [m / n for m, n in zip(measured_throughputs, nominal_throughputs)]

# Calcolo delle somme e fairness index
sums = [sum(normalized_throughputs[i:i+3]) for i in range(0, len(normalized_throughputs), 3)]
square_of_sums = np.power(sums, 2)
squares = np.power(normalized_throughputs, 2)
sum_of_squares = [sum(squares[i:i+3]) for i in range(0, len(squares), 3)]

fairness_indexes = [(m) / (3 * n) if n != 0 else 0 for m, n in zip(square_of_sums, sum_of_squares)]

# Output
test_names = ["FAIR", "RANDOM", "UNFAIR"]
print(f"Numero di throughput misurati: {len(measured_throughputs)}")
print(f"Numero di throughput nominali: {len(nominal_throughputs)}")
print(f"Lista dei Fairness Index: {fairness_indexes}")

# Stampa dei fairness index con valori puliti
for i, fi in enumerate(fairness_indexes):
    if i < len(test_names):
        print(f"FAIRNESS INDEX {test_names[i]}: {float(fi)}")
    else:
        print(f"FAIRNESS INDEX Test {i+1}: {float(fi)}")
